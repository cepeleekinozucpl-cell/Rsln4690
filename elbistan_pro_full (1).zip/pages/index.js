import Link from 'next/link'
export default function Home(){ 
  return (
    <div style={{maxWidth:800,margin:'40px auto',fontFamily:'Arial'}}>
      <h1>Elbistan Yardım Sistemi (Demo)</h1>
      <p>Dernekler ve yöneticiler için yardım takip uygulaması.</p>
      <div style={{display:'flex',gap:12}}>
        <Link href="/login"><a style={{padding:8,background:'#2563eb',color:'#fff',borderRadius:6}}>Giriş</a></Link>
        <Link href="/register"><a style={{padding:8,background:'#10b981',color:'#fff',borderRadius:6}}>Dernek Kayıt</a></Link>
      </div>
    </div>
  )
}
