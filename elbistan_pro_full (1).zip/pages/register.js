import {useState} from 'react'
export default function Register(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [phone,setPhone]=useState('');
  const onSubmit=async e=>{ e.preventDefault();
    const r=await fetch('/api/derneks', {method:'POST', body: JSON.stringify({name,email,phone})});
    const j=await r.json();
    if(j.ok) alert('Kayıt başarılı'); else alert(j.msg||'Hata');
  }
  return (
    <div style={{maxWidth:520,margin:'40px auto',fontFamily:'Arial'}}>
      <h2>Dernek Kayıt</h2>
      <form onSubmit={onSubmit}>
        <input placeholder="Dernek adı" value={name} onChange={e=>setName(e.target.value)} style={{width:'100%',padding:8,marginBottom:8}} />
        <input placeholder="E-posta" value={email} onChange={e=>setEmail(e.target.value)} style={{width:'100%',padding:8,marginBottom:8}} />
        <input placeholder="Telefon" value={phone} onChange={e=>setPhone(e.target.value)} style={{width:'100%',padding:8,marginBottom:8}} />
        <button style={{padding:10,background:'#10b981',color:'#fff'}}>Kayıt Ol</button>
      </form>
    </div>
  )
}
