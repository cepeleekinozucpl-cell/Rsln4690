import {useState} from 'react'
import Router from 'next/router'
export default function Login(){
  const [email,setEmail]=useState(''); const [pass,setPass]=useState('');
  const onSubmit=async e=>{ e.preventDefault();
    const r=await fetch('/api/auth', {method:'POST', body: JSON.stringify({email,pass})});
    const j=await r.json();
    if(j.ok){ Router.push('/dashboard'); } else { alert(j.msg || 'Hatalı giriş'); }
  }
  return (
    <div style={{maxWidth:520,margin:'40px auto',fontFamily:'Arial'}}>
      <h2>Giriş</h2>
      <form onSubmit={onSubmit}>
        <input placeholder="E-posta" value={email} onChange={e=>setEmail(e.target.value)} style={{width:'100%',padding:8,marginBottom:8}} />
        <input placeholder="Şifre" type="password" value={pass} onChange={e=>setPass(e.target.value)} style={{width:'100%',padding:8,marginBottom:8}} />
        <button style={{padding:10,background:'#2563eb',color:'#fff'}}>Giriş</button>
      </form>
      <p style={{marginTop:12}}>Demo admin: superadmin / Elbistan2025*</p>
    </div>
  )
}
