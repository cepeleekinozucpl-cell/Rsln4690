// Basit demo auth - production için değiştirin
import { readDB, writeDB } from '../../utils/db';
export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end();
  const {email,pass} = JSON.parse(req.body || '{}');
  const users = await readDB('users.json');
  const u = users.find(x=> x.email===email && x.pass===pass);
  if(u) return res.json({ok:true, user:{email:u.email,role:u.role}});
  return res.json({ok:false, msg:'Kullanıcı bulunamadı'});
}
