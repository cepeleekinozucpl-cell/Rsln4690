import { readDB, writeDB } from '../../utils/db';
export default async function handler(req,res){
  if(req.method==='GET'){
    const f=await readDB('families.json'); return res.json(f);
  }
  if(req.method==='POST'){
    const body=JSON.parse(req.body||'{}');
    if(!body.tc || !body.name) return res.json({ok:false,msg:'tc ve name gerekli'});
    const f=await readDB('families.json');
    const exists=f.find(x=> x.tc===body.tc);
    if(exists) return res.json({ok:false,msg:'Bu aile zaten kayıtlı — tekrar yardım önlenir'});
    const newF={name:body.name,tc:body.tc,lastHelp:null,helpedBy:null,id:Date.now()};
    f.push(newF);
    await writeDB('families.json',f);
    return res.json({ok:true, family:newF});
  }
  res.status(405).end();
}
