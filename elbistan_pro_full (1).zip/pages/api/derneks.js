import { readDB, writeDB } from '../../utils/db';
export default async function handler(req,res){
  if(req.method==='GET'){
    const d=await readDB('derneks.json'); return res.json(d);
  }
  if(req.method==='POST'){
    const body=JSON.parse(req.body||'{}');
    const d=await readDB('derneks.json');
    const exists=d.find(x=>x.email===body.email);
    if(exists) return res.json({ok:false,msg:'Bu e-posta ile kayıtlı dernek var'});
    d.push({...body, id: Date.now()});
    await writeDB('derneks.json',d);
    return res.json({ok:true});
  }
  res.status(405).end();
}
