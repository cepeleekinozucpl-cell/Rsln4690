import {useEffect,useState} from 'react'
export default function Dashboard(){
  const [families,setFamilies]=useState([]); const [name,setName]=useState(''); const [tc,setTc]=useState('');
  useEffect(()=>{ fetch('/api/families').then(r=>r.json()).then(setFamilies) },[]);
  const add=async e=>{ e.preventDefault();
    const r=await fetch('/api/families',{method:'POST', body: JSON.stringify({name,tc})});
    const j=await r.json();
    if(j.ok){ setFamilies(prev=>[...prev,{name,tc,lastHelp:null,helpedBy:null}]); setName(''); setTc(''); }
    else alert(j.msg||'Hata');
  }
  return (
    <div style={{maxWidth:900,margin:'30px auto',fontFamily:'Arial'}}>
      <h2>Dashboard — Aile Yönetimi</h2>
      <form onSubmit={add} style={{marginBottom:18}}>
        <input placeholder="Aile adı" value={name} onChange={e=>setName(e.target.value)} style={{padding:8,marginRight:8}} />
        <input placeholder="TC (benzersiz)" value={tc} onChange={e=>setTc(e.target.value)} style={{padding:8,marginRight:8}} />
        <button style={{padding:8,background:'#2563eb',color:'#fff'}}>Aile Ekle</button>
      </form>
      <div>
        {families.map((f,i)=>(
          <div key={i} style={{padding:10,border:'1px solid #eee',marginBottom:8}}>
            <strong>{f.name}</strong> — TC: {f.tc} <br/> Son Yardım: {f.lastHelp || 'Yok'} — {f.helpedBy || '-'}
          </div>
        ))}
      </div>
    </div>
  )
}
