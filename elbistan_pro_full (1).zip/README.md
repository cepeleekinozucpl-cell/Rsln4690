# Elbistan Yardım Sistemi - Profesyonel (Demo)

Bu proje **demo amaçlı** hazırlanmıştır. Hızlı kurulum ve deploy için hazırlanmış Next.js uygulaması.

## Özellikler (Demo)
- Süper Admin kullanıcı (default)
- Dernek (organization) kayıt ve giriş
- Aile ekleme / düzenleme / listeleme
- Yardım kaydı ve çakışma (aynı aileye tekrar yardımın önlenmesi) kontrolü
- Rol bazlı dashboard (admin / dernek)

## Önemli - Prod ortam uyarısı
Bu demo API'leri JSON dosyalarını `/data/*.json` içinde okur/yazar. Vercel gibi serverless ortamlarda
dosya sistemi **kalıcı** değildir; gerçek kullanım için Supabase / PostgreSQL / Firebase gibi bir veritabanı bağlayın.

## Kurulum (lokal)
1. `npm install`
2. `npm run dev`
3. Aç: http://localhost:3000

## Demo admin
- kullanıcı: `superadmin`
- şifre: `Elbistan2025*`

## Prod için yapılması gerekenler
- Veritabanı (Supabase) bağla; `utils/db.js` içindeki kullanım örneğini değiştir.
- Gerçek kimlik doğrulama (JWT / OAuth / Supabase Auth)
- Dosya yükleme için S3/Supabase Storage
- HTTPS ve üretim ortamı güvenlik önlemleri
