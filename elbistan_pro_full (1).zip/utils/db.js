// Basit JSON file based db for demo
import fs from 'fs';
import path from 'path';
const dataDir = path.join(process.cwd(), 'data');
export async function readDB(filename){
  try{
    const p = path.join(dataDir, filename);
    if(!fs.existsSync(p)) return [];
    const raw = fs.readFileSync(p,'utf8');
    return JSON.parse(raw || '[]');
  }catch(e){ return []; }
}
export async function writeDB(filename, obj){
  const p = path.join(dataDir, filename);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8');
}
