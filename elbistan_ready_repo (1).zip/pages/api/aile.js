let aileler=[];
export default function handler(req,res){
 if(req.method==="POST"){
   const data=JSON.parse(req.body);
   const exists=aileler.find(a=>a.tc===data.tc);
   if(exists) return res.json({ok:false,msg:"Bu aile zaten kayıtlı"});
   aileler.push(data);
   return res.json({ok:true});
 }
 if(req.method==="GET") return res.json(aileler);
 res.status(405).end();
}