let users=[{email:"demo@dernek.com",pass:"1234"}];
export default function handler(req,res){
 if(req.method==="POST"){
   const {email,pass}=JSON.parse(req.body);
   const ok=users.find(u=>u.email===email && u.pass===pass);
   return res.json({ok:!!ok});
 }
 res.status(405).end();
}