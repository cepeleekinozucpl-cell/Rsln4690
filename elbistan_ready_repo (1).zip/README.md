# Elbistan Yardım Sistemi

## Kurulum
1. Dosyaları GitHub reposuna yükle
2. Vercel'de "New Project" → "Import GitHub" → Bu repoyu seç
3. Deploy butonuna bas

## Özellikler
- Dernek giriş sistemi
- Aile veri tabanı
- Aynı aileye tekrar yardım engelleme
